const carousel = document.getElementById('carousel');
const images = carousel.querySelectorAll('img');
const imgCount = images.length;
const angle = 360 / imgCount;

let separated = false;
let currRotation = 0;
let targetRotation = 0;
let birthdayShown = false;

// At start: all images overlap at center
images.forEach(img => {
  img.style.transform = `translate(-50%, -50%) scale(1)`;
});

// Smoothly separate images in a circle
function separateImages() {
  images.forEach((img, i) => {
    img.style.transform = `
      rotateY(${i * angle}deg)
      translateZ(320px)
      translate(-50%, -50%)
      rotateX(30deg)
      scale(1)
    `;
  });
  separated = true;
}

// Animation loop for smooth rotation
function animate() {
  currRotation += (targetRotation - currRotation) * 0.15;
  carousel.style.transform = `rotateY(${-currRotation}deg)`;
  requestAnimationFrame(animate);
}
animate();

// Show birthday text and sparkles after first rotation
function showBirthday() {
  if (birthdayShown) return;
  birthdayShown = true;
  document.getElementById('birthdayText').style.opacity = 1;
}

// Only button events for rotation
document.querySelector('.carousel-btn.left').addEventListener('click', () => {
  if (!separated) separateImages();
  targetRotation -= angle;
  showBirthday();
});

document.querySelector('.carousel-btn.right').addEventListener('click', () => {
  if (!separated) separateImages();
  targetRotation += angle;
  showBirthday();
});